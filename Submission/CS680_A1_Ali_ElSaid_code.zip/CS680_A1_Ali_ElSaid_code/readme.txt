Ali El-Said (20745892)
CS680 Assignment 1

implementations.py is a python file that contains all the algorithm implementation functions.
These functions are called for the respective scripts for each question.

To verify the output for each question just run the associated script.
(i.e. to verify Exercise 1 question 1, run E1-1.py)

Included are also copies of the datasets for ease of verification (just run the script and should work).


Python version 3.10.0 was used.
Packages used and versions:
pandas==1.4.1
numpy==1.21.4
tqdm==4.64.1
matplotlib==3.5.1
